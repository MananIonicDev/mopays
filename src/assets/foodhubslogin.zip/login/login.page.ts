import { Component, OnInit } from '@angular/core';
import * as firebase from "firebase";
import { NavController, PopoverController } from "@ionic/angular";
import { Router } from '@angular/router';
import { DatasProvider } from '../services/auth';
import { FirebaseX } from '@ionic-native/firebase-x/ngx';
import { LanguageService } from '../services/language';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  code: string = "+964"; 
  //code: string = "+258"; 
  spin: boolean = false; //spinner
  otpSent: boolean = false; //OTP sent status
  public timer = 60;
  public m = 1;
  resend: boolean = false;
  block;

  //recaptchaVerifier;
  confirmationResult: firebase.auth.ConfirmationResult;
  selected;
  verificationId;
  phoneNumber: string;
  otp; //set value after OTP is sent

  constructor(public nav: NavController, public router: Router, public languageService: LanguageService,
    public popoverController: PopoverController, public authService: DatasProvider, 
    public fb: FirebaseX, public auth: DataService) {
    //keep track of currently selected country code
    this.selected = this.languageService.selected;
    setInterval(() => {
      if (sessionStorage.getItem("code")) {
        this.code = sessionStorage.getItem("code");
      }
    }, 100);
  }

  ngOnInit() {
    //this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', { 'size': 'invisible' });
  }

 

  //Navigate to Country Codes Page
  showCodes() {
    this.nav.navigateForward("/country-code");
  }

  resendCode(){
    this.spin = false;
    this.otpSent = false;
  }

  sendOTP() {
    var phNo = this.code + this.phoneNumber
    this.spin = true;
    this.fb.verifyPhoneNumber(phNo, 60).then( (res) => {
      this.phoneNumber = phNo;
      this.otpSent = true;
      this.verificationId = res.verificationId
      this.spin = false;
      this.startTimer();

    }).catch(err => {
      this.spin = false;
      alert(err);
    })
  }

  
  verifyOTP() {
    //var otp = this.otp;
    this.spin = true;
    const credential = firebase.auth.PhoneAuthProvider.credential(this.verificationId, this.otp);
    //this.confirmationResult.confirm(otp).then((data) => {
    firebase.auth().signInWithCredential(credential).then((data: any) => {
      this.spin = false;
      //Save user uid to localStorage
      localStorage.setItem("uid", data.user.uid);
      localStorage.setItem('help', data.user.uid);
      //Save phoneNumber to localStorage
      localStorage.setItem("phoneNumber", data.user.phoneNumber);

      if (data.user.displayName) {
        this.nav.navigateRoot("/");
      }
      //navigate to profile setup page
      else  {
        this.nav.navigateRoot("/setup");
      } 
       
    }).catch(err => {
      alert(err);
      this.spin = false;
    })
 
  }

  

  startTimer(){
  
  var IntervalVar = setInterval( function() {
  
    this.timer--;
  
    if (this.timer === 0)
  
     {
  
      this.timer = 60;
  
      this.m -= 1;
  
     }
  
    if (this.m === 0)
  
     {
  
      this.timer = "00";
  
      this.m = "00";
      
      this.resend = true
  
      clearInterval(IntervalVar);
  
     }
  
  }.bind(this) , 1000)
  }
}



/*  //code: string = "+964"; 
  code: string = "+964"; 
  spin: boolean = false; //spinner
  otpSent: boolean = false; //OTP sent status
  public timer = 60;
  public m = 1;
  resend: boolean = false;
  block;

  recaptchaVerifier;
  confirmationResult: firebase.auth.ConfirmationResult;
  selected;

  phoneNumber: string; //set value after OTP is sent

  constructor(public nav: NavController, public router: Router, public languageService: LanguageService,
    public popoverController: PopoverController, public authService: DatasProvider) {
    //keep track of currently selected country code
    this.selected = this.languageService.selected;
    setInterval(() => {
      if (sessionStorage.getItem("code")) {
        this.code = sessionStorage.getItem("code");
      }
    }, 100);
  }

  ngOnInit() {
    this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', { 'size': 'invisible' });
  }

 

  //Navigate to Country Codes Page
  showCodes() {
    this.nav.navigateForward("/country-code");
  }

  resendCode(){
    this.spin = false;
    this.otpSent = false;
  }

  sendOTP() {
    var phNo = this.code + (<HTMLInputElement>document.getElementById("phoneNumber")).value;

    this.spin = true;

    firebase.auth().signInWithPhoneNumber(phNo, this.recaptchaVerifier).then(result => {

      this.phoneNumber = phNo;
      this.otpSent = true;
      this.confirmationResult = result;
      this.spin = false;
      this.startTimer();

    }).catch(err => {
      this.spin = false;
      alert(err);
    })
  }

  /*sendSMSVerify(phone) {
    return new Promise((resolve, reject) => {
      this.fb.verifyPhoneNumber('+' + phone.area.callingCode + phone.tel, 120).then( (res) => {
        resolve(res);
      }).catch((err) => {
        console.log(err);
        reject(err);
      });
    });
  }

  phoneAuth(verifId, code, phone, action = 'login') {
    return new Promise((resolve, reject) => {
      const credential = firebase.auth.PhoneAuthProvider.credential(verifId, code);

      firebase.auth().signInWithCredential(credential).then((res: any) => {
        if (!res.user.phoneNumber || !this.user.phone) {
          phone = '+' + phone.area.callingCode + phone.tel;
          this.db.updateUser(res.user.uid, {phone: phone}).then(() => {});
        }

        if (action === 'login') {
          this.setUserGlobalVariable(res.user.uid).then(() => {
            resolve('Successfully logged in using phone number');
          });
        } else {
          resolve(res.user);
        }
      }).catch(err => {
        reject(err);
      });
    });
  }


  verifyOTP() {
    var otp = (<HTMLInputElement>document.getElementById("otp")).value;
    this.spin = true;
    this.confirmationResult.confirm(otp).then((data) => {
      this.spin = false;
      //Save user uid to localStorage
      localStorage.setItem("uid", data.user.uid);
      localStorage.setItem('help', data.user.uid);
      //Save phoneNumber to localStorage
      localStorage.setItem("phoneNumber", data.user.phoneNumber);

      if (data.user.displayName) {
        this.nav.navigateRoot("/");
      }
      //navigate to profile setup page
      else  {
        this.nav.navigateRoot("/setup");
      } 
       
    }).catch(err => {
      alert(err);
      this.spin = false;
    })
 
  }

  

  startTimer(){
  
  var IntervalVar = setInterval( function() {
  
    this.timer--;
  
    if (this.timer === 0)
  
     {
  
      this.timer = 60;
  
      this.m -= 1;
  
     }
  
    if (this.m === 0)
  
     {
  
      this.timer = "00";
  
      this.m = "00";
      
      this.resend = true
  
      clearInterval(IntervalVar);
  
     }
  
  }.bind(this) , 1000)
  }
}*/




 